# élora — Beauty & Fragrance Website

Current product:
- **Sauvage Dior** — EGP 600 — Men's Fragrance

Website files:
- `index.html`
- `style.css`
- `script.js`
- `logo.png`
- `sauvage-dior.jpeg`

Replace the sample products in `script.js` as you add your real products.
