const products = [
  {
    id: "sauvage-dior",
    name: "Sauvage Dior",
    category: "Men",
    description: "Men's fragrance.",
    price: 600,
    image: "sauvage-dior.jpeg"
  },
  {
    id: "signature-glow",
    name: "Signature Glow",
    category: "Makeup",
    description: "A beauty essential for your everyday glow.",
    price: 450
  },
  {
    id: "velvet-muse",
    name: "Velvet Muse",
    category: "Makeup",
    description: "Soft, elegant and made for every mood.",
    price: 520
  },
  {
    id: "rose-elixir",
    name: "Rose Élixir",
    category: "Women",
    description: "A feminine fragrance with a delicate character.",
    price: 850
  },
  {
    id: "noir-elixir",
    name: "Noir Élixir",
    category: "Men",
    description: "A deep, confident fragrance for him.",
    price: 900
  },
  {
    id: "blush-veil",
    name: "Blush Veil",
    category: "Makeup",
    description: "A fresh finishing touch for your beauty routine.",
    price: 390
  }
];

let cart = [];
let currentProducts = products;

function renderProducts(list = products) {
  currentProducts = list;
  const container = document.getElementById("products");

  container.innerHTML = list.map((p) => `
    <article class="product-card">
      <div class="product-image ${p.image ? "has-image" : ""}">
        ${p.image ? `<img src="${p.image}" alt="${p.name}">` : p.name}
      </div>
      <h3>${p.name}</h3>
      <p>${p.description}</p>
      <div class="price">EGP ${p.price.toLocaleString()}</div>
      <button class="add" onclick="addToCart('${p.id}')">Add to bag</button>
    </article>
  `).join("");
}

function filterProducts(category, button) {
  if (button) {
    document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
    button.classList.add("active");
  }
  const list = category === "All"
    ? products
    : products.filter(p => p.category === category);
  renderProducts(list);
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  if (!product) return;
  cart.push(product);
  document.getElementById("cart-count").textContent = cart.length;
  renderCart();
  openCart();
}

function renderCart() {
  const box = document.getElementById("cart-items");
  if (!cart.length) {
    box.innerHTML = "<p>Your bag is empty.</p>";
  } else {
    box.innerHTML = cart.map((p, i) =>
      `<div class="cart-row">
        <span>${p.name}</span>
        <span>EGP ${p.price.toLocaleString()}
          <button onclick="removeFromCart(${i})" style="border:0;background:none;cursor:pointer">×</button>
        </span>
      </div>`
    ).join("");
  }

  const total = cart.reduce((sum, p) => sum + p.price, 0);
  document.getElementById("cart-total").textContent = "EGP " + total.toLocaleString();
}

function removeFromCart(i) {
  cart.splice(i, 1);
  document.getElementById("cart-count").textContent = cart.length;
  renderCart();
}

function openCart() {
  document.getElementById("cart-modal").classList.add("show");
  document.getElementById("cart-modal").setAttribute("aria-hidden", "false");
  renderCart();
}

function closeCart() {
  document.getElementById("cart-modal").classList.remove("show");
  document.getElementById("cart-modal").setAttribute("aria-hidden", "true");
}

document.getElementById("cart-modal").addEventListener("click", e => {
  if (e.target.id === "cart-modal") closeCart();
});

renderProducts();
